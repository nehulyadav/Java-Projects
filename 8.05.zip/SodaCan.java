
public class SodaCan {
	/*	
	 P 8.05, Big Java Late Objects, CSE 271 D
	 Authored by yadavn, Nehul Yadav 
	 The code is robust, debugged and runnable.
	 																*/
			
		private static double heightOfCan;
		private static double radiusOfCan;
		
		/* To the best of my knowledge, a way of assigning values can be to get the keyboard input
		from the user using a Scanner class, creating its 'new' object & calling on the nextInt() on the object created.
		 */
		
		//the constructor is called in loadclass.java, which contains the main method.
		
		public SodaCan (double heightOfCan, double radiusOfCan) {
			setHeightOfCan(heightOfCan);
			setRadiusOfCan(radiusOfCan);
			
			
		}
		
		public double getSurfaceArea() {
			return 2*Math.PI*radiusOfCan*radiusOfCan + 2*Math.PI*radiusOfCan*heightOfCan;
		}
		
		public double getVolume() {
			return Math.PI*radiusOfCan*radiusOfCan*heightOfCan;
		}

		public double getHeightOfCan() {
			return heightOfCan;
		}

		public void setHeightOfCan(double heightOfCan) {
			SodaCan.heightOfCan = heightOfCan;
		}

		public double getRadiusOfCan() {
			return radiusOfCan;
		}

		public void setRadiusOfCan(double radiusOfCan) {
			SodaCan.radiusOfCan = radiusOfCan;
		}
		
}
	

