
public class loadclass {

	public static void main(String[] args){
		new SodaCan(0, 0);
	}
}
