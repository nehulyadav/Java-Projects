import java.util.Scanner;
// prompts the user for the reverse polish notation expressions and inputs the file directory.
public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the file name");
		String response = scan.nextLine();
		//readFile(response);
		Stack obj = new Stack();
		System.out.println(obj);
	}
}
